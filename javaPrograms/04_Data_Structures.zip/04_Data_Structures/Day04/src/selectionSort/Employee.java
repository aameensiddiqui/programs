package selectionSort;

public class Employee {
	private int salary;

	public Employee(int salary) {
		this.salary = salary;
	}
	
	public int getSal() {
		return salary;
	}
	
	public String toString() {
		return salary+" ";
	}
}
