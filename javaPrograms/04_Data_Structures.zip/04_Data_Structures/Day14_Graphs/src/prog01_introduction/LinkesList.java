package prog01_introduction;

public class LinkesList {

}
