package circularList;

public class LinkedList {

}
